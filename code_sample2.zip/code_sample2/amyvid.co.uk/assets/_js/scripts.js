// Wait for the page and all the DOM to be fully loaded

$(function(){






/**********************************MAIN NAVIGATION ADDING SELECTED CLASS **********************************/
	var currentLoc = window.location.pathname;
	var currentPage = currentLoc.substring(currentLoc.lastIndexOf('/') + 1);
	$('nav li a').each(function() {
	if($(this).attr('href')===currentPage) {
     $(this).parent('li').addClass('selected');
       }
      });
	
/**********************************MAIN NAVIGATION ADDING SELECTED CLASS ENDS**********************************/



/**********************************PIE CHART ANIMATION STARTS**********************************/
  $('.chart_animation').waypoint(function(direction){
	$("#div7,#div2,#div3,#div4,#div5,#div6,#div1").each(function(big) {
    $(this).delay(big * 400).fadeIn(1000);
	//$(this).show('scale', {duration: 5000,easing: 'easeOutBounce'}); 
	

});

$(".tenp,.sixp,.twop,.two_p,.threep,.fourp,.sevenp").each(function(small) {
    $(this).delay(small * 400).fadeIn(1000);
});

  }, {
    triggerOnce: true
  });  
/**********************************PIE CHART ANIMATION ENDS**********************************/


/**********************************COUNTER ANIMATION STARTS **********************************/
  $('#sec-4').waypoint(function(direction){
    function createCounter(elementId, start, end, totalTime, callback)
    {
      var jTarget = jQuery("#" + elementId);
      var interval = totalTime / (end - start);
      var intervalId;
      var current = start;
      var f = function()
        {
          jTarget.text(current);
          if (current == end)
          {
            clearInterval(intervalId);
            if (callback)
            {
              callback();
            }
          }++current;
        }
      intervalId = setInterval(f, interval);
      f();
    }
    createCounter("counterBlue", 0, 98, 2000, function()
    {
      // alert("finished")
    });
    $('#blue-gradient').animate(
    {
      height: '96%'
    }, 2300, function()
    {
      //$('#button').val('down');
    });
    createCounter("counterOrange", 0, 70, 2000, function()
    {
      //alert("finished")
    });
    $('#orange-gradient').animate(
    {
      height: '70%'
    }, 2300, function()
    {
      //$('#button').val('down');
    });
  }, {
    triggerOnce: true
  }); 
  
  /**********************************COUNTER ANIMATION ENDS**********************************/
  
  
  
  /********************************* MARIE & SIMON ********************************/
  $('.marie-container').waypoint(
  {
    handler: function(direction)
    {
      $('.marie-img').toggleClass('sticky-top');
      //change position to fixed by adding 'sticky-top' class
    }
  });
  $('#presimon').waypoint(
  {
    offset: $('.marie-img').height(),
    //calculate menu's height and margin before footer
    handler: function(direction)
    {
      $('.marie-img').toggleClass('sticky-top'); //remove 'sticky-top' class
      $('.marie-container').toggleClass('sticky-bottom'); //change position to absolute for the wrapper
    }
  });
  $('.simon-container').waypoint(
  {
    handler: function(direction)
    {
      $('div.simon-img').toggleClass('sticky-top'); //change position to fixed by adding 'sticky-top' class
    }
  });
  $('#aftersimon').waypoint(
  {
    offset: $('.simon-img').height(),
    //calculate menu's height and margin before footer
    handler: function(direction)
    {
      $('.simon-img').toggleClass('sticky-top'); //remove 'sticky-top' class
      $('.simon-container').toggleClass('sticky-bottom-simon'); //change position to absolute for the wrapper
    }
  });
  


  /****************************************** CAROUSEL/SLIDER STARTS *****************************************/
  
  
  var blockSlider = false;
  // RIGHT & LEFT functionality
  $('#carousel-left-btn').click(function()
  {
    var index = $('.carousel-nav .slide-buttons').index($('.slide-buttons.active'));
    if (index == 0)
    {
      $('.carousel-nav .slide-buttons:last').trigger('click');
    }
    else
    {
      $('.carousel-nav .slide-buttons').eq(index - 1).trigger('click');
    }
  });
  $('#carousel-right-btn').click(function()
  {
    var index = $('.carousel-nav .slide-buttons').index($('.slide-buttons.active'));
    if (index == $('.carousel-nav .slide-buttons').length - 1)
    {
      $('.carousel-nav .slide-buttons:first').trigger('click');
    }
    else
    {
      $('.carousel-nav .slide-buttons').eq(index + 1).trigger('click');
    }
  });
  // Top Nav with cirlces to go to right slide
  $('.carousel-nav .slide-buttons').click(function()
  {
    if (blockSlider)
    {
      return;
    }
    blockSlider = true;
    $('.carousel-nav .slide-buttons').removeClass('active');
    $(this).addClass('active');
    var index = $('.carousel-nav .slide-buttons').index($(this));
    var $slide = $(".carousel-mover .carousel-slide").eq(index);
    $('.carousel-nav-currentslide').animate(
    {
      "left": $(this).position().left
    }, "slow", function()
    {
      blockSlider = false;
    });
    $(".carousel-mover").animate(
    {
      "left": -$slide.width() * index
    }, "slow");
  });
  
  /****************************************** CAROUSEL/SLIDER ENDS *****************************************/
  
  
  /****************************************** DROPDOWN MENUS ******************************************/
  $('.subnavhidden,.dropdown-menu,.dropdown-menu.img').hover(

  function()
  {
    $(this).stop(true,true).animate({
      height: $('.moreinfo').height()
    });
  }, function()
  {
    $(this).stop(true,true).animate({
      height: 21
    });
  });
  
  
  
  //****************************************** MAIN SUBNAV STARTS ******************************************
  // Set Variables to DOM
  var sub_nav_container = $(".sub-nav");
  var subnav = $(".sub-nav ul");
  $('.sub-nav ul').css('top', '40px');
  sub_nav_container.waypoint(
  {
    handler: function(event, direction)
    {
      subnav.toggleClass('sticky', direction == 'down');
      if (direction == 'down') sub_nav_container.css(
      {
        'height': subnav.outerHeight()
      });
      else sub_nav_container.css(
      {
        'height': 'auto'
      });
    },
    offset: 105
  });
    //****************************************** MAIN SUBNAV ENDS **************************************
  
  
  
  
  //****************************************** PATIENT STARTS ******************************************
  // Set Variables to DOM
  var patient_sub_nav_container = $(".patient-cases-sub-nav");
  var patient_cases_subnav = $(".patient-cases-sub-nav ul");
  $('.patient-cases-sub-nav ul').css('top', '40px');
  patient_sub_nav_container.waypoint(
  {
    handler: function(event, direction)
    {
      patient_cases_subnav.toggleClass('sticky', direction == 'down');
      if (direction == 'down') patient_sub_nav_container.css(
      {
        'height': patient_cases_subnav.outerHeight()
      });
      else patient_sub_nav_container.css(
      {
        'height': 'auto'
      });
    },
    offset: 40
  });
  //******************************************MAIN NAV BLUE STARTS STICKY******************************************
  // Set Variables to DOM
  var nav_container = $(".nav-container");
  var nav = $("nav");
  nav_container.waypoint(
  {
    handler: function(event, direction)
    {
      nav.toggleClass('sticky', direction == 'down');
      if (direction == 'down') nav_container.css(
      {
        'height': nav.outerHeight()
      });
      else nav_container.css(
      {
        'height': 'auto'
      });
    },
    offset: 15
  });
  //******************************************MAIN NAV ENDS******************************************
  
  //This is for vertical navigation(one page naviagtion), as you move down the page the nav section becomes hot.
  var sections = $(".section");
  var navigation_links = $(".sub-nav a");
  sections.waypoint(
  {
    handler: function(event, direction)
    {
      var active_section;
      active_section = $(this);
      if (direction === "up") active_section = active_section.prev();
      var active_link = $('.sub-nav a[href="#' + active_section.attr("id") + '"]');
      navigation_links.removeClass("selected");
      active_link.addClass("selected");
    },
    offset: '25%'
  })
  navigation_links.click(function(event)
  {
    $.scrollTo(
    $(this).attr("href"), {
      duration: 500,
      offset: {
        'left': 0,
        'top': -0.15 * $(window).height()
      }
    });
  });
  //******************************************MAIN NAV ENDS******************************************
  //This is for vertical navigation(one page naviagtion), as you move down the page the nav section becomes hot.
  var case_studies_sections = $(".case-studies-section");
  var patient_navigation_links = $(".patient-cases-sub-nav a");
  case_studies_sections.waypoint(
  {
    handler: function(event, direction)
    {
      var active_case_section;
      active_case_section = $(this);
      if (direction === "up") active_case_section = active_case_section.prev();
      var active_link = $('.patient-cases-sub-nav a[href="#' + active_case_section.attr("id") + '"]');
      patient_navigation_links.removeClass("selected");
      active_link.addClass("selected");
    },
    offset: '25%'
  })
  patient_navigation_links.click(function(event)
  {
    $.scrollTo(
    $(this).attr("href"), {
      duration: 500,
      offset: {
        'left': 0,
        'top': -0.15 * $(window).height()
      }
    });
  });
  /* Individual Page Scroll */
    $(".to-case-studies-main").click(function(event)
  {
    $.scrollTo($("#main"), {
      duration: 500,
      offset: {
        'left': 0,
        'top': -0.15 * $(window).height()
      }
    });
  }); 
     $(".to-simon").click(function(event)
  {
    $.scrollTo($("#simon"), {
      duration: 500,
      offset: {
        'left': 0,
        'top': -0.15 * $(window).height()
      }
    });
  }); 
  /* Individual Page Scroll */
  $(".to-top").click(function(event)
  {
    $.scrollTo($("#sec-1"), {
      duration: 500,
      offset: {
        'left': 0,
        'top': -0.15 * $(window).height()
      }
    });
  });
  $(".to-clinical").click(function(event)
  {
    $.scrollTo($(".about-2"), {
      duration: 500,
      offset: {
        'left': 0,
        'top': -0.15 * $(window).height()
      }
    });
  });
  $(".to-desired").click(function(event)
  {
    $.scrollTo($("#sec-4"), {
      duration: 500,
      offset: {
        'left': 0,
        'top': -0.15 * $(window).height()
      }
    });
  });
  $(".to-complicating").click(function(event)
  {
    $.scrollTo($("#sec-5"), {
      duration: 500,
      offset: {
        'left': 0,
        'top': -0.15 * $(window).height()
      }
    });
  });
  $(".to-pathology ").click(function(event)
  {
    $.scrollTo($("#sec-6"), {
      duration: 500,
      offset: {
        'left': 0,
        'top': -0.15 * $(window).height()
      }
    });
  });
  //******************************************ACCORDION STARTS******************************************
  
        /*********Close all on Click ***/
   $('.closeAll').on('click',function(){
   $('.accordionButton').removeClass('on');
   $('div.accordionContent').slideUp('normal');
	});
      /*********Close all on Click ***/
	$('.expandAll').on('click',function(){
  $('.accordionButton').addClass('on');
   $('div.accordionContent').slideDown('normal');
  });
  
  
  
  $('.accordionButton').click(function()
  {
 
		//REMOVE THE ON CLASS FROM ALL BUTTONS
		//$('.accordionButton').removeClass('on');
		  
		//NO MATTER WHAT WE CLOSE ALL OPEN SLIDES
        var self = this;
        $(this).next().slideToggle('normal', function() {
             $(self).toggleClass('on', $(this).is(':visible'));                                   
        });
	 });
	  
	
	/*** REMOVE IF MOUSEOVER IS NOT REQUIRED ***/
	


   /*********Close all on page Load***/
  $('.accordionContent').hide();
  //******************************************ACCORDION ENDS******************************************	
  // Tab Content Slider/ Switcher

  function contentSwitcher(settings)
  {
    var settings = {
      contentClass: '.content, .con-content',
      navigationId: '#question-main-navigation, #con-navigation'
    };
    //Hide all of the content except the first one on the nav
    $(settings.contentClass).not(':first').hide();
    $(settings.navigationId).find('li:first').addClass('active');
    //onClick set the active state, hide the content panels and show the correct one
    $(settings.navigationId).find('a').click(function(e)
    {
      var contentToShow = $(this).attr('href');
      contentToShow = $(contentToShow);
      //dissable normal link behaviour
      e.preventDefault();
      //set the proper active class for active state css
      $(settings.navigationId).find('li').removeClass('active');
      $(this).parent('li').addClass('active');
      //hide the old content and show the new
      $(settings.contentClass).hide();
      contentToShow.show();
    });
  }
  contentSwitcher();
  //Moving Arrow
  var currentPosition = 0;
  var moveWidth = 270;
  $('ul#question-nav').delegate("li", "click", function()
  {
    currentPosition = ($(this).index());
    $('#movingarrow').animate(
    {
      'left': moveWidth * (currentPosition)
    }, 450);
  });
  //Moving Arrow
  var currentPosition = 0;
  var moveConWidth = 120;
  $('ul#con-navigation-nav').delegate("li", "click", function()
  {
    currentPosition = ($(this).index());
    $('.con-arrow ').animate(
    {
      'top': moveConWidth * (currentPosition)
    }, 150);
  });
  
  
  

  
  
});