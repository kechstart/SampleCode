//GET THE URL, base on the Page then apply that json Content file

$(function() {
    switch (ati.currentLoc) {
        case 'drugsmarijuana':
            getdrugfactsContent('/_json/drugfacts/marijuana.json');
            jQuery(this).addClass('selectedDrugNav');
            break;
        case 'drugspainkillers':
            getdrugfactsContent('/_json/drugfacts/painskiller.json');
            break;
        case 'drugsdepressants':
            getdrugfactsContent('/_json/drugfacts/depressants.json');
            break;
        case 'drugsstimulants':
            getdrugfactsContent('/_json/drugfacts/stimulants.json');
            break;
        case 'drugsghb':
            getdrugfactsContent('/_json/drugfacts/ghb.json');
            break;
        case 'drugspresciptionrx':
            getdrugfactsContent('/_json/drugfacts/presciptionrx.json');
            break;
        case 'drugsotc':
            getdrugfactsContent('/_json/drugfacts/otc.json');
            break;
        case 'drugsalcohol':
            getdrugfactsContent('/_json/drugfacts/alcohol.json');
            break;
        case 'drugscocaine':
            getdrugfactsContent('/_json/drugfacts/cocaine.json');
            break;
        case 'drugssteroids':
            getdrugfactsContent('/_json/drugfacts/steroids.json');
            break;
        case 'drugsecstasy':
            getdrugfactsContent('/_json/drugfacts/ecstasy.json');
            break;
        case 'drugsmeth':
            getdrugfactsContent('/_json/drugfacts/meth.json');
            break;
        case 'drugsheroin':
            getdrugfactsContent('/_json/drugfacts/heroin.json');
            break;
        case 'drugsketamine':
            getdrugfactsContent('/_json/drugfacts/ketamine.json');
            break;
        case 'drugsrohypnol':
            getdrugfactsContent('/_json/drugfacts/rohypnol.json');
            break;
        case 'drugshallucinogens':
            getdrugfactsContent('/_json/drugfacts/hallucinogens.json');
            break;
        case 'drugsinhalants':
            getdrugfactsContent('/_json/drugfacts/inhalants.json');
            break;
        case 'drugstobacco':
            getdrugfactsContent('/_json/drugfacts/tobacco.json');
            break;
        case 'drugsbathsalts':
            getdrugfactsContent('/_json/drugfacts/bathsalts.json');
            break;
        case 'drugsdxm':
            getdrugfactsContent('/_json/drugfacts/dxm.json');
            break;
        case 'drugslsd':
            getdrugfactsContent('/_json/drugfacts/lsd.json');
            break;
        case 'drugsmushrooms':
            getdrugfactsContent('/_json/drugfacts/mushrooms.json');
            break;
        case 'drugssalvia':
            getdrugfactsContent('/_json/drugfacts/salvia.json');
            break;
        case 'drugssources':
            getdrugfactsContent('/_json/drugfacts/sources.json');
            break;
        // FAIL SAFE
        default:
            return false;
        //standing fast
    }
});

$("document").ready(function() {
    // Landing Page Slide Show Config
    // Only Execute if user is on drugfact landing page
    if(ati.currentLoc === 'drugfacts') {
        $('.slideShow').slideShow({
            randomize : true,
            interval : 3
        });
    };

    // Load Landing/Secondary Page Navigation
    $.getJSON('/_json/drugfacts/drugfacts_nav.json', function(data) {
        $(".nav").html('');
        $(".the_menu").html('');

        // Parse Nav Data
        $(data.drugfacts_nav).each(function(index, drugfacts_nav) {
            // Render Landing Page Nav
            $(".nav").append('<li><a  href="/facts/' + drugfacts_nav.link + '">' + drugfacts_nav.name + ' </a></li>');
            $(".the_menu").append('<li><a  href="/facts/' + drugfacts_nav.link + '">' + drugfacts_nav.name + ' </a></li>');

            // Render Secondary Page Nav
            jQuery('.nav a').each(function() {
                if(jQuery(this).attr('href') === window.location.pathname) {
                    jQuery(this).addClass('selecteddrugnav');
                }
            });
        });
    });
    // MENU DROP DOWN - Targets The Main Class and UL, applies the slide Toddle Animation. The UL elements inside is hidden by Default
    $('.drugfacts_menu').click(function() {
        $('ul.the_menu').slideToggle('medium');
    });
});
// GET ALL DRUG FACTS CONTENT
function getdrugfactsContent(content) {
    // Writes Sources link to the End of the Left Nav
    $('div#drugsfacts_leftcolumn_nav').append('<a class="txtcolor_fff" href="/facts/drugssources">View all sources</a>');

    $.getJSON(content, function(data) {
        //GET DRUG CONTENT START INFORMATION START
        $(data.drugfacts_content).each(function(index, drugfacts_content) {
            $("#drugfacts_rightmain").append('<h1 class="nomargin_top marginbottom_10px fontfamily_Anton fontsize_42px txtcolor_000">' + drugfacts_content.title + '</h1>');
            $("#drugfacts_rightmain").append('<p class="titleintro">' + drugfacts_content.lowdown + '</p>');

            var images = drugfacts_content.images;
            for(var i = 0; i < images.length; i++) {
                $("#drugfacts_rightmain").append('<img class="drugfacts_thumnail" src="/_img/' + images[i] + '" />');
            }

            $('#drugfacts_rightmain').append('<br /><br /><h3 class="fontfamily_Anton fontsize_18px txtcolor_000">' + drugfacts_content.aka_title + '</h3><p>' + drugfacts_content.aka + '</p><h3 class="fontfamily_Anton fontsize_18px txtcolor_000">' + drugfacts_content.what_title + '</h3><p>' + drugfacts_content.what + '</p><h3 class="fontfamily_Anton fontsize_18px txtcolor_000">' + drugfacts_content.risk_title + '</h3><p>' + drugfacts_content.risk + '</p><h3 class="fontfamily_Anton fontsize_18px txtcolor_000">' + drugfacts_content.longterm_title + '</h3><p>' + drugfacts_content.longterm + '</p><h3 class="fontfamily_Anton fontsize_18px txtcolor_000">' + drugfacts_content.bottomline_title + '</h3><p>' + drugfacts_content.bottomline + '</p><div class="facebook_drugfacts"><a onclick="_gaq.push([\'_trackEvent\', \'Drug Facts\', \'Drug FB Share Clicked\', \'' + drugfacts_content.title + '\']);" href="http://www.facebook.com/dialog/feed?app_id=277276458968231&link=' + drugfacts_content.fblink + '&name=' + drugfacts_content.fbname + '&caption=' + drugfacts_content.fbcaption + '&description=' + drugfacts_content.fbdescription + '&redirect_uri=http://www.facebook.com&picture=http://abovetheinfluence.com/_img/atilogo_sz75.png" target="_blank"><img alt="Facebook Share" src="/_img/btn_facebookshare.png" /></a><div>');
            $('div.hotline').append('<p class="left marginright_10px fontsize_25px">' + drugfacts_content.hotline_title + '</p><p class="left marginright_5px fontsize_24px">' + drugfacts_content.hotline_number + '</p><p class="right txtsize_16px">' + drugfacts_content.hotline_description + '</p>');
            $('div.classnotes').append('<p class="left margintop_2px fontsize_25px txtcolor_fff fontfamily_Anton">' + drugfacts_content.notes_title + '</p><img class="notesicon left" src="' + drugfacts_content.notes_icon + '" width="44" height="41" alt="" />');
            $('div.classnotes').live('click', function(e) {
                window.open(drugfacts_content.notes_url, "_blank");
                e.preventDefault();
            });
            //GET DRUG CONTENT START INFORMATION ENDS
        });
        // CUSTOM RX 
        $(data.Painkillers_content).each(function(index, Painkillers_content) {
            $("#drugfacts_painkillers").append('<h1 class="fontfamily_Anton fontsize_26px txtcolor_000">' + Painkillers_content.title + '</h1> ');
            $("#drugfacts_painkillers").append('<p class="titleintro">' + Painkillers_content.lowdown + '</p> ');
            $("#drugfacts_painkillers").append('<h3 class="margin5_bottom fontfamily_Anton fontsize_18px txtcolor_000">' + Painkillers_content.aka_title + '</h3><p>' + Painkillers_content.aka + '</p><h3 class="margin5_bottom fontfamily_Anton fontsize_18px txtcolor_000">' + Painkillers_content.what_title + '</h3><p>' + Painkillers_content.what + '</p><h3 class="margin5_bottom fontfamily_Anton fontsize_18px txtcolor_000">' + Painkillers_content.risk_title + '</h3><p>' + Painkillers_content.risk + '</p><h3 class="margin5_bottom fontfamily_Anton fontsize_18px txtcolor_000">' + Painkillers_content.longterm_title + '</h3><p>' + Painkillers_content.longterm + '</p><h3 class="margin5_bottom fontfamily_Anton fontsize_18px txtcolor_000">' + Painkillers_content.bottomline_title + '</h3><p>' + Painkillers_content.bottomline + '</p>');
            //GET DRUG CONTENT START INFORMATION ENDS
            //GET FACEBOOK SHARE INFO
            //$("#drugfacts_rightmain_Painkillers").append('<div class="facebook_drugfacts" ><a href="http://www.facebook.com/dialog/feed?app_id=277276458968231&link=' + Painkillers_content.fblink + '&name=' + Painkillers_content.fbname + '&caption=' + Painkillers_content.fbcaption + '&description=' + Painkillers_content.fbdescription + '&redirect_uri=http://www.facebook.com&picture=' + Painkillers_content.fbimage + '" target="_blank"><img alt="Facebook Share" src="/_img/btn_facebookshare.png" /></a><div>');
        });
        // Depressants
        $(data.Depressants_content).each(function(index, Depressants_content) {
            $("#drugfacts_depressants").append('<h1 class="fontfamily_Anton fontsize_26px txtcolor_000">' + Depressants_content.title + '</h1> ');
            $("#drugfacts_depressants").append('<p class="titleintro">' + Depressants_content.lowdown + '</p> ');
            $("#drugfacts_depressants").append('<h3 class="margin5_bottom fontfamily_Anton fontsize_18px txtcolor_000">' + Depressants_content.aka_title + '</h3><p>' + Depressants_content.aka + '</p><h3 class="margin5_bottom fontfamily_Anton fontsize_18px txtcolor_000">' + Depressants_content.what_title + '</h3><p>' + Depressants_content.what + '</p><h3 class="margin5_bottom fontfamily_Anton fontsize_18px txtcolor_000">' + Depressants_content.risk_title + '</h3><p>' + Depressants_content.risk + '</p><h3 class="margin5_bottom fontfamily_Anton fontsize_18px txtcolor_000">' + Depressants_content.longterm_title + '</h3> <p>' + Depressants_content.longterm + '</p><h3 class="margin5_bottom fontfamily_Anton fontsize_18px txtcolor_000">' + Depressants_content.bottomline_title + '</h3><p>' + Depressants_content.bottomline + '</p>');

            //GET DRUG CONTENT START INFORMATION ENDS
            //GET FACEBOOK SHARE INFO
            //$("#drugfacts_rightmain_Depressants").append('<div class="facebook_drugfacts" ><a href="http://www.facebook.com/dialog/feed?app_id=277276458968231&link=' + Depressants_content.fblink + '&name=' + Depressants_content.fbname + '&caption=' + Depressants_content.fbcaption + '&description=' + Depressants_content.fbdescription + '&redirect_uri=http://www.facebook.com&picture=' + Depressants_content.fbimage + '" target="_blank"><img alt="Facebook Share" src="/_img/btn_facebookshare.png" /></a><div>');
        });
        // Stimulants 
        $(data.Stimulants_content).each(function(index, Stimulants_content) {
            $("#drugfacts_stimulants").append('<h1 class="fontfamily_Anton fontsize_26px txtcolor_000">' + Stimulants_content.title + '</h1> ');
            $("#drugfacts_stimulants").append('<p class="titleintro">' + Stimulants_content.lowdown + '</p> ');
            $("#drugfacts_stimulants").append('<h3 class="margin5_bottom fontfamily_Anton fontsize_18px txtcolor_000">' + Stimulants_content.aka_title + '</h3><p>' + Stimulants_content.aka + '</p><h3 class="margin5_bottom fontfamily_Anton fontsize_18px txtcolor_000">' + Stimulants_content.what_title + '</h3><p>' + Stimulants_content.what + '</p><h3 class="margin5_bottom fontfamily_Anton fontsize_18px txtcolor_000">' + Stimulants_content.risk_title + '</h3><p>' + Stimulants_content.risk + '</p><h3 class="margin5_bottom fontfamily_Anton fontsize_18px txtcolor_000">' + Stimulants_content.longterm_title + '</h3><p>' + Stimulants_content.longterm + '</p><h3 class="margin5_bottom fontfamily_Anton fontsize_18px txtcolor_000">' + Stimulants_content.bottomline_title + '</h3><p>' + Stimulants_content.bottomline + '</p>');

            //GET DRUG CONTENT START INFORMATION ENDS
            //GET FACEBOOK SHARE INFO
            //$("#drugfacts_rightmain_Stimulants").append('<div class="facebook_drugfacts" ><a href="http://www.facebook.com/dialog/feed?app_id=277276458968231&link=' + Stimulants_content.fblink + '&name=' + Stimulants_content.fbname + '&caption=' + Stimulants_content.fbcaption + '&description=' + Stimulants_content.fbdescription + '&redirect_uri=http://www.facebook.com&picture=' + Stimulants_content.fbimage + '" target="_blank"><img alt="Facebook Share" src="/_img/btn_facebookshare.png" /></a><div>');
        });

        //GET THE REALITY CHECK METER
        $(data.realitycheck_content).each(function(index, realitycheck_content) {
            $("#drugfacts_widget_realitycheck").append('<div class="reality_container_left left"><h3 class="fontfamily_Anton fontsize_20px txtcolor_000 nopadding_nomargin_top_bottom">' + realitycheck_content.realitychecktitle + '</h3><strong>' + realitycheck_content.realitychecktitleintro + '</strong><p class="txtcolor_fff fontsize_25px fontfamily_Anton">"' + realitycheck_content.realitycheckdescription + '"</p></div>');
        });
        
        // SOURCES
        $(data.sources_content).each(function(index, sources_content) {
            //Removes any undefinded objects or empty ones using one of the objects names, I choose to use link.
            if(!( typeof sources_content.link === "undefined" || sources_content.link.length < 1)) {
                // need it to skip the first element
                $("#source_id").append('<li><span class="txt_bold">' + sources_content.sc_id + '.</span> <span class="txt_normal">' + sources_content.copy + '</span><br /><a href="' + sources_content.link + '" target="_blank">' + sources_content.link + '</a><br /><span class="fontsize_12px txtcolor_000">' + sources_content.date + '</span></li>');
            }
        });
        //GET THE PRESSURE METER CONTENT STARTS
        $("#slides").html('');
        $("#menu").html('');

        var randompressure = data.pressuremeter_content;
        randompressure.sort(function(a, b) {
            return Math.random() - 0.5;
        });
        if(randompressure.length < 5) {

            $.getJSON('/_json/drugfacts/drugfacts_generic.json', function(data) {
                //alert("randompressure within getJSON callback: " + randompressure);
                var randombalance = (5 - randompressure.length);
                //alert("randombalance=" + randombalance);

                var genericFiltered = data.pressuremeter_content;
                genericFiltered.sort(function(a, b) {
                    return Math.random() - 0.5;
                });
                genericFiltered = $.grep(genericFiltered, function(value, i) {
                    return i < randombalance;
                });
                randompressure = randompressure.concat(genericFiltered);

                appendFacts(randompressure);
                //alert("randompressure when it started < 5 and we made it 5" + randompressure);
            });
        } else if(randompressure.length >= 5) {
            randompressure = $.grep(randompressure, function(value, i) {
                return i < 5;
            });
            appendFacts(randompressure);
        }
    });
}

//APPENDING THE SLIDE FUNCTION STARRTS
var appendFacts = function(factsArray) {
    $("#slides").append('<div class="meter_slide"><div class="pressure_meter_container_left"><h3 class="fontfamily_Anton txtcolor_000 fontsize_20px nopadding_nomargin_top_bottom">PRESSURE METER</h3><p class="txtcolor_fff txtsize_20px fontfamily_Anton">Pressures can affect you at any time, but the more you know, the better informed you’ll be to make the right decisions. <span class="dark_green">The more knowledge you gain, the more the Pressure Meter to the right will decrease.</span> </p></div><div class="pressure_meter_container_right"><img src="/_img/pressuremeter_0.png" /><div class="nextslide txtcolor_fff"> <strong>START</strong></div></div>');
    $(factsArray).each(function(index, pressuremeter_content) {
        //alert(index);
        $("#slides").append('<div class="meter_slide"><div class="pressure_meter_container_left"><h3 class="fontfamily_Anton fontsize_20px txtcolor_000 nopadding_nomargin_top_bottom">' + pressuremeter_content.pressuremetertitle + '</h3><strong>The more you know, the more the pressure drops.</strong><br /><strong>' + pressuremeter_content.pressuremetertitleintro + '</strong><p class="fontfamily_Anton txtcolor_fff fontsize_20px">' + pressuremeter_content.pressuremeterdescription + '</p></div><div class="pressure_meter_container_right"><img  class="align_right"  src="/_img/pressuremeter_' + index + '.png" /><div class="nextslide txtcolor_fff"> <strong>NEXT</strong></div></div>');
        //GET FACEBOOK SHARE INFO
    });
    $("#slides").append('<div class="meter_slide"><div class="pressure_meter_container_left"><h3 class="fontfamily_Anton fontsize_20px txtcolor_000 nopadding_nomargin_top_bottom">PRESSURE METER</h3><p class="txtcolor_fff txtsize_20px fontfamily_Anton">You\'\ve completely decreased the pressure meter and are on your way to becoming an expert on drugs and pressures that surround them. <span class="dark_green">Click "Start Over" to brush up on these facts again or <a class="fontsize_18px" href="/facts/drugfacts/">click here</a> to increase your knowledge on other drugs.</span></p></div><div class="pressure_meter_container_right"  ><img src="/_img/pressuremeter_4.png" /><div class="nextslide txtcolor_fff" style="padding:1px 0 0 10px"><strong>START<br>OVER</strong></div></div>');
    //GET THE PRESSURE METER CONTENT ENDS

    //PRESSURE METER SLIDER STARTES
    var totWidth = 0;
    var positions = new Array();

    $('#slides .meter_slide').each(function(i) {

        /* Traverse through all the slides and store their accumulative widths in totWidth */
        positions[i] = totWidth;
        totWidth += $(this).width();

        /* The positions array contains each slide's commulutative offset from the left part of the container */

        if(!$(this).width()) {
            alert("Please, fill in width & height for all your images!");
            return false;
        }

    });

    $('#slides').width(totWidth);

    /* Change the container div's width to the exact width of all the slides combined */
    var pos = 0;

    $('div.nextslide').click(function(e) {
        /* On a thumbnail click */
        //$('li.menuItem').removeClass('act').addClass('inact');
        //$(this).parent().addClass('act');

        pos = (pos + 1) % 7;
        $('#slides').stop().animate({
            marginLeft : -positions[pos] + 'px'
        }, 450);
        /* Start the sliding animation */
        e.preventDefault();
        /* Prevent the default action of the link */
        // Stopping the auto-advance if an icon has been clicked
    });

    $('#menu ul li.menuItem:first').addClass('act').siblings().addClass('inact');
    /* On page load, mark the first thumbnail as active */
    //PRESSURE METER SLIDER END

    // Create the tooltips only on document load

    // Make sure to only match links to wikipedia with a rel tag
    $('sup.annotaion').each(function() {
        var positionat = parseInt($(this).html());
        // We make use of the .each() loop to gain access to each element via the "this" keyword...
        $(this).qtip({
            content : {
                // Set the text to an image HTML string with the correct src URL to the loading image you want to use
                text : 'Loading....',
                ajax : {
                    url : '/_json/drugfacts/sources.json', // URL to the JSON script
                    type : 'GET', // POST or GET
                    data : {}, // Data to pass along with your request
                    dataType : 'json', // Tell it we're retrieving JSON
                    success : function(data, status) {
                        /*  Process the retrieved JSON object
                         *  Retrieve a specific attribute from our parsed
                         *  JSON string and set the tooltip content.
                         */
                        var annotationcontent = data.sources_content;
                        annotationcontent = jQuery.grep(annotationcontent, function(n, i) {
                            return (i == positionat);
                        });
                        // Now we set the content manually (required!)
                        this.set('content.text', '<strong class="fontsize_12px">' + annotationcontent[0].copy + '</strong><br />(<a class="fontsize_12px"  target="blank" href=" ' + annotationcontent[0].link + '">' + annotationcontent[0].link + '</a> )<br /><span class="fontsize_12px">' + annotationcontent[0].date + '</span>');
                    }
                },
                title : {
                    // Give the tooltip a title using each elements text
                    text : 'Drug Facts Source - ' + $(this).text(),
                    button : true
                }
            },
            position : {
                at : 'bottom center', // Position the tooltip above the link
                my : 'top center',
                viewport : $(window), // Keep the tooltip on-screen at all times
                effect : false // Disable positioning animation
            },
            show : {
                event : 'click',
                solo : true // Only show one tooltip at a time
            },
            hide : 'unfocus',
            style : {
                classes : 'ui-tooltip-ati-pages'
            }
        });
    });
    // Make sure it doesn't follow the link when we click it
    $.click(function(event) {
        event.preventDefault();
    });
};
