$(document).ready(function(){
	// Make sure to only match links to wikipedia with a rel tag
    $('a.references').each(function() {
    	var positionat = parseInt($(this).html());
    	var $this = $(this);
    	var references = $this.attr("data-footnote");
		$.fn.qtip.zindex = 2; // Non-modal z-index
		$.fn.qtip.plugins.modal.zindex = 2; // Modal-specific z-index
        
        // We make use of the .each() loop to gain access to each element via the "this" keyword...
		
		$.getJSON('./assets/_json/ref.json', function(data) {
				$.each(data, function(key, val) {
					if (references == key) {

							 $this.qtip({
								content: {
									// Set the text to an image HTML string with the correct src URL to the loading image you want to use
									text:'<span class="tip-arrow"><img src="./assets/_img/ref-arrow-top.png"/></span><section class="ref-overlay small bold">'+ val +'</section><span class="fontsize_12px"></span>',            
								

									title: {
										// Give the tooltip a title using each elements text
										button:false
										
									}
								},
								position: {
									at:'bottom left', // Position the tooltip above the link
									//viewport:$(window), // Keep the tooltip on-screen at all times
									target: false,
									effect:true // Disable positioning animation
								},
								show: {
									event:'mouseover',
									
								},
								hide: { event: 'unfocus', fixed: true },
								style: {
									classes:'qtip-blue',
      								
      								tip: false,
      							 width: {max: 250} }
      							
      						
						});
					}
				});
				});
				});
	$('a.clinical').each(function() {
    	var positionat = parseInt($(this).html());
    	var $this = $(this);
    	var references = $this.attr("data-footnote");
		$.fn.qtip.zindex = 2; // Non-modal z-index
		$.fn.qtip.plugins.modal.zindex = 2;
			$.getJSON('./assets/_json/ref.json', function(data) {
				$.each(data, function(key, val) {
					if (references == key) {

							 $this.qtip({
								content: {
									// Set the text to an image HTML string with the correct src URL to the loading image you want to use
									text:'<span class="tip-arrow"><img src="./assets/_img/ref-arrow-top.png"/></span><section class="ref-overlay study small bold">'+ val +'</section><span class="fontsize_12px"></span>',            
								

									title: {
										// Give the tooltip a title using each elements text
										button:false
										
									}
								},
								position: {
									at:'bottom left', // Position the tooltip above the link
									//viewport:$(window), // Keep the tooltip on-screen at all times
									target: false,
									effect:true // Disable positioning animation
								},
								show: {
									event:'hover',
									solo:true // Only show one tooltip at a time
								},
								hide: { when: 'mouseout', fixed: true },
								style: {
									classes:'qtip-blue',
      								
      								tip: false,
      							 width: {max: 452} }
      							
      						
						});
					}
				});
				});
				});
			});
