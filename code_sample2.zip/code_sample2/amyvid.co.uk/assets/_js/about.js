// Wait for the page and all the DOM to be fully loaded

$(function() {

$('#sec-4').waypoint(function(direction) 
{
  
    function createCounter(elementId, start, end, totalTime, callback) {
     var jTarget = jQuery("#" + elementId);
     var interval = totalTime / (end - start);
     var intervalId;
     var current = start;
     var f = function () {
         jTarget.text(current);
         if (current == end) {
             clearInterval(intervalId);
             if (callback) {
                 callback();
             }
         }++current;
     }
     intervalId = setInterval(f, interval);
     f();
 }
     createCounter("counterTarget", 0, 92, 2000, function () {
        // alert("finished")
     });
	  createCounter("counterTarget1", 0, 100, 2000, function () {
         //alert("finished")
     });
 },{ triggerOnce: true}
);



$('#sec-6').waypoint(function(direction) 
{
  
    function createCounter(elementId, start, end, totalTime, callback) {
     var jTarget = jQuery("#" + elementId);
     var interval = totalTime / (end - start);
     var intervalId;
     var current = start;
     var f = function () {
         jTarget.text(current);
         if (current == end) {
             clearInterval(intervalId);
             if (callback) {
                 callback();
             }
         }++current;
     }
     intervalId = setInterval(f, interval);
     f();
 }
	  createCounter("counterTarget2", 0, 94, 3000, function () {
         //alert("finished")
     });
},  
{ triggerOnce: true}
);

 //****************************************** SUBNAV STARTS ******************************************
	// Do our DOM lookups beforehand
	var about_sub_nav_container = $(".about-sub-nav");
	var about_subnav = $("ul.sub-nav-about");
$('ul.sub-nav-about').css({
	'top': '30px',
	'background':'url(./assets/_img/gradient_nav.png) no-repeat top left',
	'padding-top': '10px'});
	about_sub_nav_container.waypoint({
		handler: function(event, direction) {
			about_subnav.toggleClass('sticky', direction=='down');
			
			
			if (direction == 'down') about_sub_nav_container.css({ 'height':about_subnav.outerHeight() });
			else about_sub_nav_container.css({ 'height':'auto' });
		},
		offset: 105
	});


  //******************************************MAIN NAV ENDS******************************************
	
	//This is for vertical navigation(one page naviagtion), as you move down the page the nav section becomes hot.
	var about_sections = $(".about-section");
	var about_navigation_links = $(".about-sub-nav a");
	
	about_sections.waypoint({
		handler: function(event, direction) {
		
			var active_about_section;
			active_about_section = $(this);
			if (direction === "up") active_about_section = active_about_section.prev();

			var active_link = $('.about-sub-nav a[href="#' + active_about_section.attr("id") + '"]');
			about_navigation_links.removeClass("selected");
			active_link.addClass("selected");

		},
		offset: 400
	})
	
	about_navigation_links.click( function(event) {

		$.scrollTo(
			$(this).attr("href"),
			{
				duration: 500,
				offset: { 'left':0, 'top':-0.25*$(window).height() }
			}
		);
	});
	
  //******************************************MAIN NAV ENDS******************************************
	
	//This is for vertical navigation(one page naviagtion), as you move down the page the nav section becomes hot.
	var case_studies_sections = $(".case-studies-section");
	var patient_navigation_links = $(".patient-cases-sub-nav a");
	
	case_studies_sections.waypoint({
		handler: function(event, direction) {
		
			var active_case_section;
			active_case_section = $(this);
			if (direction === "up") active_case_section = active_case_section.prev();

			var active_link = $('.patient-cases-sub-nav a[href="#' + active_case_section.attr("id") + '"]');
			patient_navigation_links.removeClass("selected");
			active_link.addClass("selected");

		},
		offset: '25%'
	})
	
	patient_navigation_links.click( function(event) {

		$.scrollTo(
			$(this).attr("href"),
			{
				duration: 500,
				offset: { 'left':0, 'top':-0.25*$(window).height()}}); 
	});
	/* Individual Page Scroll - about */
	$(".to-top").click( function(event) {$.scrollTo($(".about-top"),{duration: 500,offset: 
	{ 'left':0, 'top':-0.15*$(window).height() }});
	});
	$(".find-more").click( function(event) {$.scrollTo($(".about-2"),{duration: 500,offset: 
	{ 'left':0, 'top':-0.25*$(window).height() }});
	});
	/* Individual Page Scroll */

	$(".to-accurate").click( function(event) {$.scrollTo($("#sec-4"),{duration: 500,offset: 
	{ 'left':0, 'top':-0.25*$(window).height() }});
	});
	$(".to-effective").click( function(event) {$.scrollTo($("#sec-5"),{duration: 500,offset: 
	{ 'left':0, 'top':-0.25*$(window).height() }});
	});
	$(".to-reliable").click( function(event) {$.scrollTo($("#sec-6"),{duration: 500,offset: 
	{ 'left':0, 'top':-0.25*$(window).height() }});
	});
	
	$(".to-tolerability ").click( function(event) {$.scrollTo($("#sec-7"),{duration: 500,offset: 
	{ 'left':0, 'top':-0.15*$(window).height() }});
	});
	$(".to-imaging ").click( function(event) {$.scrollTo($("#sec-8"),{duration: 500,offset: 
	{ 'left':0, 'top':-0.15*$(window).height() }});
	});
	$(".to-additional ").click( function(event) {$.scrollTo($("#sec-9"),{duration: 500,offset: 
	{ 'left':0, 'top':-0.15*$(window).height() }});
	});
});

