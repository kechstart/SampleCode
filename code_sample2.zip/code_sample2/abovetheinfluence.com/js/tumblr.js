/* Author:
Nkeche Alexander  Draftfcb: Web Developer
*/
// START JQUERY
$(document).ready(function() {

	tumblrDataFeed.getTmbrFeed();
});
//Data Feed Object Namespace
var tumblrDataFeed = {

	//declaring my local array variable
	tumblrdata : [],
	d : '',

	//Get Tumbr Data Function
	getTmbrFeed : function() {
		$.getJSON('http://ondcp.tumblr.com/api/read/json?callback=?', function(data) {
			//tumblrDataFeed.tumblrdata = data;
			tumblrDataFeed.tumblrdata = data.posts;
			tumblrDataFeed.getTmbrFeedCheck();
		});
	},
	//Get Tumbr Data Function Ends

	// Check to see if my Tumblr Data is loaded
	getTmbrFeedCheck : function() {
		if(tumblrDataFeed.tumblrdata === []) {
			tumblrDataFeed.getTmbrFeed();
		} else {
			tumblrDataFeed.displayTmbrFeed();
		}

	},
	//Display My Tumblr Post

	displayTmbrFeed : function() {

		var mypost = tumblrDataFeed.tumblrdata;
		var tmbrbodylength = 75;

		//Looping through to get data
		for(var i = 0; i < mypost.length; i++) {

			//Date Data -//Use the Date Jquery to converse the date parse out
			var d = Date.parse(mypost[i]["date"]);
			var dateFmt = tumblrDataFeed.formatDate(d);

			//Body Data
			var tmbrBody = mypost[i]["regular-body"];
			var shortTmbrBody = tmbrBody.trim().substring(0, tmbrbodylength).split(" ").slice(0, -1).join(" ") + "";
			$("#tumblrFeed").append("<div class='thelatest_entry'><div><div class='date leftfloat textcolor_333 paddingtop_15px fontsize_25px fontfamily_Anton'>" + dateFmt + "</div><div class='left width_150 marginleft_10px'><div class='body expandable leftfloat paddingtop_10px'>" + shortTmbrBody + "</div><a href='/news' class='txtcolor_ltblue' onclick=\"_gaq.push(['_trackEvent', 'ATI Homepage', 'Content Clicked', 'The Latest']);\">Read More</a></div></div></div>");

		}

	},
	formatDate : function(d) {
		return d.toString('MMM d');
	}
};
